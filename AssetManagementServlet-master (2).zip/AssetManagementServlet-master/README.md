This is my first servlet project.
Project about It Asset Management.

Using javascript,html,css,java

here I used to display a details jtable.
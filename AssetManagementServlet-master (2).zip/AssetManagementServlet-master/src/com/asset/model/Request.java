package com.asset.model;

public class Request {
	
	private String reqId;
	private String empId;
	private String empName;
	private String reqType;
	private String reqTypeId;
	private String reqName;
	private String reqVer;
	private String reqQry;
	private String reqStatus;
	private String reqStat;
	public String getReqId() {
		return reqId;
	}
	public void setReqId(String reqId) {
		this.reqId = reqId;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getReqType() {
		return reqType;
	}
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}
	public String getReqTypeId() {
		return reqTypeId;
	}
	public void setReqTypeId(String reqTypeId) {
		this.reqTypeId = reqTypeId;
	}
	public String getReqName() {
		return reqName;
	}
	public void setReqName(String reqName) {
		this.reqName = reqName;
	}
	public String getReqVer() {
		return reqVer;
	}
	public void setReqVer(String reqVer) {
		this.reqVer = reqVer;
	}
	public String getReqQry() {
		return reqQry;
	}
	public void setReqQry(String reqQry) {
		this.reqQry = reqQry;
	}
	public String getReqStatus() {
		return reqStatus;
	}
	public void setReqStatus(String reqStatus) {
		this.reqStatus = reqStatus;
	}
	public String getReqStat() {
		return reqStat;
	}
	public void setReqStat(String reqStat) {
		this.reqStat = reqStat;
	}
	
		
}

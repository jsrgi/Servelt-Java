package com.asset.model;

public class Software {
	
	private String softId;
	private String softName;
	private String softVer;
	private String softLice;
	private String softPlat;
	private String softAvl;
	
	
	public String getSoftId() {
		return softId;
	}
	public void setSoftId(String softId) {
		this.softId = softId;
	}
	public String getSoftName() {
		return softName;
	}
	public void setSoftName(String softName) {
		this.softName = softName;
	}
	public String getSoftVer() {
		return softVer;
	}
	public void setSoftVer(String softVer) {
		this.softVer = softVer;
	}
	public String getSoftLice() {
		return softLice;
	}
	public void setSoftLice(String softLice) {
		this.softLice = softLice;
	}
	public String getSoftPlat() {
		return softPlat;
	}
	public void setSoftPlat(String softPlat) {
		this.softPlat = softPlat;
	}
	public String getSoftAvl() {
		return softAvl;
	}
	public void setSoftAvl(String softAvl) {
		this.softAvl = softAvl;
	}
	
	

}

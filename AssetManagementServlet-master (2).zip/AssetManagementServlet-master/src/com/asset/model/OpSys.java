package com.asset.model;

public class OpSys {
	
	private String osId;
	private String osType;
	private String osVer;
	private String osLice;
	private String osBit;
	private String osCost;
	private String osAvl;
	
	public String getOsId() {
		return osId;
	}
	public void setOsId(String osId) {
		this.osId = osId;
	}
	public String getOsType() {
		return osType;
	}
	public void setOsType(String osType) {
		this.osType = osType;
	}
	public String getOsVer() {
		return osVer;
	}
	public void setOsVer(String osVer) {
		this.osVer = osVer;
	}
	public String getOsLice() {
		return osLice;
	}
	public void setOsLice(String osLice) {
		this.osLice = osLice;
	}
	public String getOsBit() {
		return osBit;
	}
	public void setOsBit(String osBit) {
		this.osBit = osBit;
	}
	public String getOsCost() {
		return osCost;
	}
	public void setOsCost(String osCost) {
		this.osCost = osCost;
	}
	public String getOsAvl() {
		return osAvl;
	}
	public void setOsAvl(String osAvl) {
		this.osAvl = osAvl;
	}
	
	
	
}

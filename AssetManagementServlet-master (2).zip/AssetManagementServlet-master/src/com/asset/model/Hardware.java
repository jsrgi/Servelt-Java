package com.asset.model;

public class Hardware {
	
	private String hardId;
	private String hardCat;
	private String hardBrand;
	private String hardDes;
	private String hardStock;
	private String hardWar;
	
	
	public String getHardId() {
		return hardId;
	}
	public void setHardId(String hardId) {
		this.hardId = hardId;
	}
	public String getHardCat() {
		return hardCat;
	}
	public void setHardCat(String hardCat) {
		this.hardCat = hardCat;
	}
	public String getHardBrand() {
		return hardBrand;
	}
	public void setHardBrand(String hardBrand) {
		this.hardBrand = hardBrand;
	}
	public String getHardDes() {
		return hardDes;
	}
	public void setHardDes(String hardDes) {
		this.hardDes = hardDes;
	}
	public String getHardStock() {
		return hardStock;
	}
	public void setHardStock(String hardStock) {
		this.hardStock = hardStock;
	}
	public String getHardWar() {
		return hardWar;
	}
	public void setHardWar(String hardWar) {
		this.hardWar = hardWar;
	}

}

package com.asset.model;

public class Count {
	
	private int empCnt;
	private int osCnt;
	private int hardCnt;
	private int softCnt;
	private int reqCnt;
	private int comCnt;
	private int reqAcc;
	private int reqRej;
	private int reqReq;
	private int comCom;
	private int comIn;
	private int comView;
	private int comSol;
	
	
	public int getEmpCnt() {
		return empCnt;
	}
	public void setEmpCnt(int empCnt) {
		this.empCnt = empCnt;
	}
	public int getOsCnt() {
		return osCnt;
	}
	public void setOsCnt(int osCnt) {
		this.osCnt = osCnt;
	}
	public int getHardCnt() {
		return hardCnt;
	}
	public void setHardCnt(int hardCnt) {
		this.hardCnt = hardCnt;
	}
	public int getSoftCnt() {
		return softCnt;
	}
	public void setSoftCnt(int softCnt) {
		this.softCnt = softCnt;
	}
	public int getReqCnt() {
		return reqCnt;
	}
	public void setReqCnt(int reqCnt) {
		this.reqCnt = reqCnt;
	}
	public int getComCnt() {
		return comCnt;
	}
	public void setComCnt(int comCnt) {
		this.comCnt = comCnt;
	}
	public int getReqAcc() {
		return reqAcc;
	}
	public void setReqAcc(int reqAcc) {
		this.reqAcc = reqAcc;
	}
	public int getReqRej() {
		return reqRej;
	}
	public void setReqRej(int reqRej) {
		this.reqRej = reqRej;
	}
	public int getReqReq() {
		return reqReq;
	}
	public void setReqReq(int reqReq) {
		this.reqReq = reqReq;
	}
	public int getComCom() {
		return comCom;
	}
	public void setComCom(int comCom) {
		this.comCom = comCom;
	}
	public int getComIn() {
		return comIn;
	}
	public void setComIn(int comIn) {
		this.comIn = comIn;
	}
	public int getComView() {
		return comView;
	}
	public void setComView(int comView) {
		this.comView = comView;
	}
	public int getComSol() {
		return comSol;
	}
	public void setComSol(int comSol) {
		this.comSol = comSol;
	}
	
}

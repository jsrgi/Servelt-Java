// Toggle Function
$('.toggle').on("click", function() {
	// Switches the Icon
	
	$(this).children('i').toggleClass('fa-pencil');
	$(".forgot_div").hide();
	

	if($('.login_div').css('display') =='none' && $('.register_div').css('display')=='none' ){
		$('.register_div').css('display','block');
	}
	
	$('.toggle_form').animate({
		height : "toggle",
		'padding-top' : 'toggle',
		'padding-bottom' : 'toggle',
		opacity : "toggle"
	}, "slow");
	

});
$('.cta').on("click", function() {
	
	$(this).children('i').toggleClass('fa-pencil');

	$(".login_div").hide();
	$(".register_div").hide();
	
	$('.forgot_div').animate({
		height : "toggle",
		'padding-top' : 'toggle',
		'padding-bottom' : 'toggle',
		opacity : "toggle"
	}, "slow");
	
	
});

$('.addincome').on("click", function() {
	// Switches the Icon
	alert();
	$(".add_income_form").css('display','block');
	

});


	  $('#loginaccount').on('click',function() {
		 
			$.ajax({
				url : 'loginaccount',
				method:'post',
				data : {
					'username':$('#username').val(),'password':$('#password').val()
				},
				success : function(responseText) {
					if(responseText=='fail')
						$('#error').text("Username/Password Incorrect");
					else
						window.location.replace("home.html");
				}
			});
		});
	  
	

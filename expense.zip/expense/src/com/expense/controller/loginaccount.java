package com.expense.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.expense.Dao.createaccountDao;

/**
 * Servlet implementation class loginaccount
 */
@WebServlet("/loginaccount")
public class loginaccount extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String result=new createaccountDao().login(request);
		System.out.println(result);
		if(result.equalsIgnoreCase("success"))
			//request.getRequestDispatcher("home.html").include(request, response);
			response.setContentType("text/plain");
			response.getWriter().write(result);
	}

}

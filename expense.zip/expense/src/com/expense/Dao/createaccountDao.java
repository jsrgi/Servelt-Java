package com.expense.Dao;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;

public class createaccountDao {

	public int insert(HttpServletRequest request) {

		int result = 0;
		Connection con = null;

		try {

			con = new dbconn().getCon();

			Statement stmt = con.createStatement();
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			String mobile = request.getParameter("mobile");

			result = stmt.executeUpdate("INSERT INTO createaccount (username,password,email,mobile)" + "VALUES ('"
					+ username + "','" + password + "','" + email + "','" + mobile + "')");

			con.close();
		} catch (Exception e) {
			System.out.println("createaccount " + e);
		}
		return result;
	}

	public String login(HttpServletRequest request) {
		String result = "fail";
		Connection con = null;

		try {

			con = new dbconn().getCon();

			Statement stmt = con.createStatement();
			String username = request.getParameter("username");
			String password = request.getParameter("password");
System.out.println(username);
			ResultSet rs = stmt.executeQuery(
					"SELECt *FROM createaccount where username='" + username + "' and password='" + password + "'");

			while (rs.next()) {
				result = "success";
				
			}

			con.close();
		} catch (Exception e) {
			System.out.println("createaccount " + e);
		}
		return result;
	}
}

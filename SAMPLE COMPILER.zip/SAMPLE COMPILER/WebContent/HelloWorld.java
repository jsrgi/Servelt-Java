

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

/* HelloWorld.java */

public class HelloWorld {
    
    static public void main(String argv[]) {
        HelloWorld.CompileCprog("sample.c");
        
    }
    public static void CompileCprog(String filename){
        File dir = new File("G:\\Students projects 2\\meetup\\WebContent\\");
        try {  
            String exeName = filename.substring(0, filename.length() - 2);
            System.out.println(exeName);
          Process p1 = Runtime.getRuntime().exec("cmd /C gcc " + filename, null, dir);  
       Process p = Runtime.getRuntime().exec("cmd /C a.exe", null, dir); 
         // System.out.println(p.getInputStream().read());
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream())); 
           System.out.println("cmd /C gcc " + filename + " && " + exeName);
            String line = null;  
            while ((line = in.readLine()) != null) {  
                System.out.println(line);  
            }  
        } catch (IOException e) {  
           System.out.println(e);
        }   
    }
}
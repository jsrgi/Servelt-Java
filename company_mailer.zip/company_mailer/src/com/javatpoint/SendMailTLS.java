package com.javatpoint;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMailTLS {

	public static String mailsend(String fromaddress, String toAddress, String subject, String msg) {

		final String username = "xxxx@gmail.com";
		final String password = "yyyyy";
		try {
		Properties props = new Properties();
		
        props.put("mail.smtp.auth", "true");
      
       props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.starttls.enable", "true");
        props.setProperty("proxySet","true");
        props.setProperty("http.proxyHost","10.100.1.99");
        props.setProperty("http.proxyPort","8080");
		  

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromaddress));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toAddress));
			message.setRecipients(Message.RecipientType.CC, InternetAddress.parse("df@gmail.com"));
			message.setSubject(subject);
			message.setText(msg);

			Transport.send(message);

			System.out.println("Done");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
		return "success";
	}

	public static void main(String[] args) {
		
		SendMailTLS.mailsend("sms@gmail.com", "sfmm@gmail.com", "demo", "demo");
	}
}
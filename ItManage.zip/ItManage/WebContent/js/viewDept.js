$(document).ready(function() {
	debugger;
	$('#employeeList').jtable({
		title : 'Employee Details',
		actions : {
			listAction : 'GetDepNames?action=null',
			updateAction : 'GetDepNames?action=update',
			deleteAction : 'GetDepNames?action=delete'
		},
	
		fields : {			

			dep_id : {
				title : 'Id',
				width : '30%',
				key : true,
				list : true,
				edit : false,
				create : true
			},
			name : {
				title : 'Department Name',
				width : '20%',
				edit : true
				
			},
			div_name : {
				title : 'Division Name',
				width : '20%',
				edit : true
				
			},
			status: {
				title : 'Division status',
				width : '30%',
				edit : false
			}
			
			
		}
	});
	$('#employeeList').jtable('load');
}); 

$(document).ready(function() {
	debugger;
	$('#projectList').jtable({
		title : 'Project Details',
		actions : {
			listAction : 'ViewProject?action=list',
			
			updateAction : 'ViewProject?action=update',
			deleteAction : 'ViewProject?action=delete'
		},
	
		fields : {			

			p_id : {
				title : 'Project Id',
				width : '10%',
				key : true,
				list : true,
				edit : false,
				
			},
			p_name : {
				title : 'Project Name',
				width : '20%',
				edit : true
				
			},
			p_des: {
				title : 'Project detail',
				width : '30%',
				edit : true
			},
			doj: {
				title : 'Project start date',
				width : '10%',
				edit : false
			},
			AggDate : {
				title : 'End date',
				width : '10%',
				edit : true
			},
			managerDetails: {
				title : 'Manager Details',
				width : '25%',
				edit : true
			},
			Email : {
				title : 'Contact EMail ID',
				width : '25%',
				edit : true
			},
			numEmp: {
				title : 'Num of Emp',
				width : '10%',
				edit : true
			}
		}
	});
	$('#projectList').jtable('load');
}); 

$(document).ready(function() {
	debugger;
	 var StartDate= sessionStorage.getItem("StartDate");
 	  var EndDate= sessionStorage.getItem("EndDate");
 	 
	 //alert(EndDate);
	$('#employeeList').jtable({
		title : 'Employee Details',
		sorting: true,
		paging: true,
		actions : {
			listAction : 'ViewEmployee?action=list&sd='+StartDate+'&td='+EndDate,
			updateAction : 'ViewEmployee?action=update',
			deleteAction : 'ViewEmployee?action=delete'
		},
		fields : {			

			emp_id : {
				title : 'Id',
				width : '30%',
				key : true,
				list : true,
				edit : false,
				create : true
			},
			emp_idNum : {
				title : 'Emp Id',
				width : '20%',
				edit : true,
				list : true,
				
			},
			emp_fname: {
				title : 'First Name',
				width : '30%',
				edit : true
			},
			emp_lname: {
				title : 'Last Name',
				width : '30%',
				edit : true
			},
			dob : {
				title : 'Date_of_brith',
				width : '30%',
				edit : true
			},
			doj: {
				title : 'Date_of_join',
				width : '30%',
				edit : true
			},
			emp_gender : {
				title : 'Gender',
				width : '30%',
				edit : true
			},
			emp_email: {
				title : 'Email',
				width : '30%',
				edit : true
			},
			emp_role: {
				title : 'Desiganation',
				width : '30%',
				edit : true
			},
			emp_division: {
				title : 'Division',
				width : '30%',
				edit : true
			},
			emp_department: {
				title : 'Department',
				width : '30%',
				edit : true
			},
			emp_team: {
				title : 'Team',
				width : '30%',
				edit : true
			},
			emp_address: {
				title : 'Address',
				width : '30%',
				edit : true
			}
			
		}/*,
		toolbar: {
		    items: [{
		        icon: '/images/excel.png',
		        text: 'Export to Excel',
		        click: function () {
		            //perform your custom job...
		        }
		    },{
		        icon: '/images/pdf.png',
		        text: 'Export to Pdf',
		        click: function () {
		            //perform your custom job...
		        }
		    }]
		},*/
	});
	$('#employeeList').jtable('load');
	 //Re-load records when user click 'load records' button.
	sessionStorage.removeItem("StartDate");
	 sessionStorage.removeItem("EndDate");
    
}); 

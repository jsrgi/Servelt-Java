$(document).ready(function() {
	debugger;
	$('#employeeList').jtable({
		title : 'Division Details',
		actions : {
			listAction : 'GetDivi?action=null',
			updateAction : 'GetDivi?action=update',
			deleteAction : 'GetDivi?action=delete'
		},
	
		fields : {			

			div_id : {
				title : 'Id',
				width : '30%',
				key : true,
				list : true,
				edit : false,
				create : true
			},
			div_name : {
				title : 'Division Name',
				width : '20%',
				edit : true
				
			},
			div_cretaed: {
				title : 'Division created by',
				width : '30%',
				edit : false
			},
			div_status: {
				title : 'Division status',
				width : '30%',
				edit : false
			}
			
			
		}
	});
	$('#employeeList').jtable('load');
}); 

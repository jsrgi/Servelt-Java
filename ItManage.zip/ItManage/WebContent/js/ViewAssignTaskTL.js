$(document).ready(function() {
	debugger;
	function disablePrev() { window.history.forward() }
    window.onload = disablePrev();
    window.onpageshow = function(evt) { if (evt.persisted) disableBack() }

	var id = sessionStorage.getItem("userid");
	var pid=sessionStorage.getItem("pname");
	var uname=sessionStorage.getItem("uname");
	var name=uname+" "+"<span class='caret'></span>";
	$("#usser").empty();
	$("#usser").append(name);	
	$("#empid").val(id);
	
	$('#ViewAssignTaskList').jtable({
		title : 'Assigned Task Details',
		actions : {
			listAction : 'ViewAssignTaskTL?action=list&emp_id='+id+'&pid='+pid,
			updateAction : 'ViewAssignTaskTL?action=update&emp_id='+id+'&pid='+pid,
			deleteAction : 'ViewAssignTaskTL?action=delete&emp_id='+id+'&pid='+pid,
		},
	
		fields : {			

			t_id : {
				title : 'Task Id',
				width : '10%',
				key : true,
				list : true,
				edit : false,
				create : true
			},
			t_name : {
				title : 'Task Name',
				width : '20%',
				edit : true
				
			},
			t_des: {
				title : 'Task detail',
				width : '30%',
				edit : true
			},			
			p_name: {
				title : 'Project Name',
				width : '25%',
				edit : false
			},
			date: {
				title : 'Start date',
				width : '10%',
				edit : false
			},
			ddate : {
				title : 'Due date',
				width : '10%',
				edit : true
			},
			assignee: {
				title : 'Assignee Details',
				width : '25%',
				edit : true
			},
			create : {
				title : 'Created By',
				width : '25%',
				edit : false
			}
		}
	});
	$('#ViewAssignTaskList').jtable('load');
}); 
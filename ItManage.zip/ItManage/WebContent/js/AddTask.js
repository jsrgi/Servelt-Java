/**
 * 
 */
$(document).ready(function(){
	
	var id = sessionStorage.getItem("pname");//?pid='+id
	//alert(id)
	$.get("GetProjectNames?pid="+id,function(result){
		//debugger;
	//console.log(result)	;
	$.each(result,function( key,value ) {
			 console.log( key + ": " + value );
			 if(key=="Records"){
			  $.each(value,function( i,j ) {
	  		 console.log( i + ": " + JSON.stringify(j.p_id) );
				  $("#sProject").append(
					        $('<option value='+JSON.stringify(j.p_id)+'>'+j.p_name+'</option>')
					    );	 
				  });
			     } 
			  });
	});
	
	 $("#sProject").on('change',function(){
		 
		 var id=this.value;
       //		 var pname=$("#sProject option:selected").text();
		// alert(id);
	   // alert(pname);
		 
			$.get("GetProjectEmpDetails?pid="+id,function(result){
				//debugger;
			//console.log(result)	;
			$("#assignEmp").empty();
			$("#assignEmp").append( $('<option value="Select">Select</option>'))
			$.each(result,function( key,value ) {
					 //console.log( key + ": " + value );
					 if(key=="Records"){
					  $.each(value,function( i,j ) {
			  		 //console.log( i + ": " + j.div_name );
			  		 // alert(id);
			  		  //alert(j.p_id);
                  	  if(id==j.p_id)
			  			 {
			  			  $("#assignEmp").append(
							        $('<option value='+j.emp_id+'>'+j.emp_fname+'</option>')
							    );	
			  			 }
						  });
					     } 
					  });
			});
			GettaskNames(id) ;
		 
/*
			 $.ajax({
				    url: 'AddTask',
				   
				    data:{projectname:""+pname+""}
				
				    ,type: 'POST'

				
			}); 

			
*/		 
	 });
	
});
function GettaskNames(proid){
	//var proid=$("sProject").value();
	//alert(proid);
	$("#tname").html('');
	$("#tname").append( $('<option value="Select">Select</option>'));
	$.get("gettasknameofpro?pro_id="+proid,function(result){
		//debugger;
	//console.log(result)	;
	$.each(result,function( key,value ) {
			 
			 if(key=="Records"){
			  $.each(value,function( i,j ) {
	  		 console.log( i + ": " + JSON.stringify(j) );
	  		
	  		
				  $("#tname").append(
					        $('<option value='+JSON.stringify(j.t_id)+'>'+j.t_name+'</option>')
					    );	 
				  });
			     } 
			  });
	});	
}



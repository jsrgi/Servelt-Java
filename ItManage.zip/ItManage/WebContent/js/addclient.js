$(document).ready(function() {
	debugger;
	$('#employeeList').jtable({
		title : 'Client Details',
		actions : {
			listAction : 'AddClient?action=list',
			updateAction : 'AddClient?action=update',
			deleteAction : 'AddClient?action=delete'
		},
	
		fields : {			

			client_id : {
				title : 'Id',
				width : '30%',
				key : true,
				list : true,
				edit : false,
				create : true
			},
			clientName : {
				title : 'Client Name',
				width : '20%',
				list : true,
				edit : true
				
			},
			ClientDescription: {
				title : 'Client Description',
				width : '30%',
				edit : true
			},
			Email: {
				title : 'Email for contact',
				width : '30%',
				list : true,
				edit : true
			},
			
			doj: {
				title : 'Date of join',
				width : '30%',
				edit : true,
				list : true,
			},
			AggDate : {
				title : 'Aggrement end date',
				width : '30%',
				edit : true
			},
			ProjectDetails: {
				title : 'Project Details',
				width : '30%',
				edit : true
			},
			
			address: {
				title : 'Client Address',
				width : '30%',
				edit : true
			}
			
			
		}
	});
	$('#employeeList').jtable('load');
}); 

	
	
$(document).ready(function() {
	debugger;
	var id = sessionStorage.getItem("userid");
	var uname=sessionStorage.getItem("uname");
	var name=uname+" "+"<span class='caret'></span>";
	$("#usser").empty();
	$("#usser").append(name);	
	$("#empid").val(id);
	
	$('#projectList').jtable({
		title : 'Complaint Details',
		actions : {
			listAction : 'ViewComDet?empId='+id,
		},
	
		fields : {			

			comId : {
				title : 'Complaint Id',
				width : '10%',
				key : true,
				list : true,
				edit : false,
				
			},
			comType : {
				title : 'Complaint type',
				width : '20%',				
				edit : false,
				
			},
			comDesc : {
				title : 'Complaint description',
				width : '25%',
				edit : false,
				
			},
			comStat : {
				title : 'Admin update',
				width : '10%',
				
				edit : false
				
			},
			comRecDt : {
				title : 'Start date',
				width : '20%',
				edit : false
				
			},
			comTarDt: {
				title : 'Due date',
				width : '10%',
				edit : false
			}
		}
	

	});
	$('#projectList').jtable('load');
}); 

/**
 * 
 */
	$(document).ready(
			function() {
	 var p=0;
				        var tid=0;
				        var p1=sessionStorage.getItem("pname");
				        
			 			$.post("PassId?id="+sessionStorage.getItem("id")+"&pid="+p1,async=true, function(result) {
			 					//debugger;
			 					//console.log(result)	;

			 					$.each(result, function(key, value) {
			 						//console.log( key + ": " + value );
			 						if (key == "Records") {
			 							$.each(value, function(i, j) {
			 								
			 								$("#tname").text(j.t_name);
			 							     $("#tid").text(j.t_id);
			 								 $("#addname").text(j.create);
			 							     $("#status").text(j.status);
			 							     $("#date").text(j.date);
			 							     $("#des").text(j.t_des);
                                             $("#pname").text(j.p_name);
			 							     $("#assignee").text(j.assignee);
			 							     p=j.pro_id;
			 						         tid=j.t_id;	   
			 						 	});
			 						}
			 					});
			 					
			 					
			 				});
			 			/*var p=sessionStorage.getItem("pname");
				        var tid=sessionStorage.getItem("id");
			 			$.post("gettaskhis?id="+tid+"&pid="+p,async=true, function(result) {
			 					//debugger;
			 					//console.log(result)	;

			 					$.each(result, function(key, value) {
			 						console.log( key + ": " + value );
			 						if (key == "Records") {
			 							$.each(value, function(i, j) {
			 								
			 								$("#his").text(j.histroy);
			 							     
			 							     	   
			 						 	});
			 						}
			 					});
			 			});
			 					

                              */
			 			var p=sessionStorage.getItem("pname");
				        var tid=sessionStorage.getItem("id");
				        $.post("gettaskhis?id="+tid+"&pid="+p,async=true, function(result) {
			 					//debugger;
			 				console.log(result)	;
			 				$.each(result,function( key,value ) {
			 						 //console.log( key + ": " + value );
			 						 if(key=="Records"){
							 	
			 							 //var n=1;
			 						  $.each(value,function( i,j ) {
			 				  		 //console.log( i + ": " + j.div_name );
			 				  		 
    $( "#his" ).append('<br><li  style="color: #000000 ;">'+j.histroy +' <label  style="color:#4B0082;"> updated on  </label><label style="color:#1E90FF;">  '+ " "+j.time+'</label></li><br>');

			 				  			 
			 						  });
			 						     } 
			 						  });
			 				});
			 			 $("#edit").button().click(function(){
			 					var id= $("#tid").text();
			 				// alert(id);
			 				sessionStorage.setItem("id",id);
			 				window.location.href="TlUpdateTask.html";


			 				 
			 		    });   	
			 			 		
			
			});

$(document).ready(function() {
	debugger;
	var id = sessionStorage.getItem("pname");//&pid='+id
	$('#projectList').jtable({
		title : 'Project Details',
		actions : {
		listAction : 'viewTask?action=list&pid='+id,
				updateAction : 'viewTask?action=update&pid='+id,
				deleteAction : 'viewTask?action=delete&pid='+id
		},
	
		fields : {			

			t_id : {
				title : 'Task Id',
				width : '10%',
				key : true,
				list : true,
				edit : false,
				
			},
			t_name : {
				title : 'Task name',
				width : '20%',				
				edit : true
				
			},
			t_des : {
				title : 'Task description',
				width : '25%',
				edit : true
				
			},
			pro_id : {
				title : 'Project Id',
				width : '10%',
				
				edit : false
				
			},
			p_name : {
				title : 'Project Name',
				width : '20%',
				edit : false
				
			},
			create: {
				title : 'Created BY',
				width : '10%',
				edit : false
			}
		}
	});
	$('#projectList').jtable('load');
}); 

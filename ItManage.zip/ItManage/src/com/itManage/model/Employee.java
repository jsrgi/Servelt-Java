package com.itManage.model;

public class Employee {
	private int emp_id;
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	private String emp_idNum;
	private String emp_fname;
	private String emp_lname;
	private String dob;
	private String doj;
	private int p_id;
	private int status;
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	//Date date=new Date();
	
	public String getEmp_fname() {
		return emp_fname;
	}
	public String getEmp_idNum() {
		return emp_idNum;
	}
	public void setEmp_idNum(String emp_idNum) {
		this.emp_idNum = emp_idNum;
	}
	public void setEmp_fname(String emp_fname) {
		this.emp_fname = emp_fname;
	}
	public String getEmp_lname() {
		return emp_lname;
	}
	public void setEmp_lname(String emp_lname) {
		this.emp_lname = emp_lname;
	}
	
	public String getEmp_gender() {
		return emp_gender;
	}
	public void setEmp_gender(String emp_gender) {
		this.emp_gender = emp_gender;
	}
	public String getEmp_uname() {
		return emp_uname;
	}
	public void setEmp_uname(String emp_uname) {
		this.emp_uname = emp_uname;
	}
	public String getEmp_pass() {
		return emp_pass;
	}
	public void setEmp_pass(String emp_pass) {
		this.emp_pass = emp_pass;
	}
	
	public String getEmp_email() {
		return emp_email;
	}
	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}
	public String getEmp_role() {
		return emp_role;
	}
	public void setEmp_role(String emp_role) {
		this.emp_role = emp_role;
	}
	public String getEmp_division() {
		return emp_division;
	}
	public void setEmp_division(String emp_division) {
		this.emp_division = emp_division;
	}
	public String getEmp_department() {
		return emp_department;
	}
	public void setEmp_department(String emp_department) {
		this.emp_department = emp_department;
	}
	public String getEmp_team() {
		return emp_team;
	}
	public void setEmp_team(String emp_team) {
		this.emp_team = emp_team;
	}
	public String getEmp_address() {
		return emp_address;
	}
	public void setEmp_address(String emp_address) {
		this.emp_address = emp_address;
	}
	private String emp_gender;
	
	private String emp_uname;
	private String emp_pass;
	private String emp_email;
	private String emp_role;
	private String emp_division;
	private String emp_department;
	private String emp_team;
	private String emp_address;
	
	

}

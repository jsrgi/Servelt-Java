package com.itManage.model;

public class Count {
	
	
	private int div;
	private int dep;
	private int teams;
	private int emp;

    
	private int pro;

	public int getDiv() {
		return div;
	}
	public void setDiv(int div) {
		this.div = div;
	}
	public int getDep() {
		return dep;
	}
	public void setDep(int dep) {
		this.dep = dep;
	}
	public int getTeams() {
		return teams;
	}
	public void setTeams(int teams) {
		this.teams = teams;
	}
	public int getEmp() {
		return emp;
	}
	public void setEmp(int emp) {
		this.emp = emp;
	}
	
	public int getPro() {
		return pro;
	}
	public void setPro(int pro) {
		this.pro = pro;
	}
	public int getCpro() {
		return cpro;
	}
	public void setCpro(int cpro) {
		this.cpro= cpro;
	}
	public int getInpro() {
		return inpro;
	}
	public void setInpro(int inpro) {
		this.inpro = inpro;
	}
	public int getTask() {
		return task;
	}
	public void setTask(int task) {
		this.task = task;
	}
	private int cpro;
	private int inpro;
	private int task;
	

}

package com.itManage.model;

public class Divitions {
	
	private String div_name;
     private int  div_id;
     public String getDiv_cretaed() {
		return div_cretaed;
	}

	public void setDiv_cretaed(String div_cretaed) {
		this.div_cretaed = div_cretaed;
	}

	public String getDiv_status() {
		return div_status;
	}

	public void setDiv_status(String div_status) {
		this.div_status = div_status;
	}

	private String div_cretaed;
     private String div_status;
     
	public int getDiv_id() {
		return div_id;
	}

	public void setDiv_id(int div_id) {
		this.div_id = div_id;
	}

	public String getDiv_name() {
		return div_name;
	}

	public void setDiv_name(String div_name) {
		this.div_name = div_name;
	}

}

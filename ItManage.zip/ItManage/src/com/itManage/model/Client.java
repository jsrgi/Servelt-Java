package com.itManage.model;

public class Client {

	private int client_id;
	private String clientName;
	private String ClientDescription;
	private String doj;
	private String AggDate;
	private String ProjectDetails;
	private String Email;
	private String address;
	
	
	public int getClient_id() {
		return client_id;
	}
	public void setClient_id(int client_id) {
		this.client_id = client_id;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public String getClientDescription() {
		return ClientDescription;
	}
	public void setClientDescription(String clientDescription) {
		ClientDescription = clientDescription;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getAggDate() {
		return AggDate;
	}
	public void setAggDate(String aggDate) {
		AggDate = aggDate;
	}
	public String getProjectDetails() {
		return ProjectDetails;
	}
	public void setProjectDetails(String projectDetails) {
		ProjectDetails = projectDetails;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
	
}

package com.itManage.model;

public class Project {
public int emp_id;
public String  p_name;
public String p_des;
public int p_id;
private String doj;
private String AggDate;
private String managerDetails;
private String Email;
private int numEmp;


public int getP_id() {
	return p_id;
}
public void setP_id(int p_id) {
	this.p_id = p_id;
}
public int getEmp_id() {
	return emp_id;
}
public void setEmp_id(int emp_id) {
	this.emp_id = emp_id;
}
public String getP_name() {
	return p_name;
}
public void setP_name(String p_name) {
	this.p_name = p_name;
}
public String getP_des() {
	return p_des;
}
public void setP_des(String p_des) {
	this.p_des = p_des;
}
	
public String getDoj() {
	return doj;
}
public void setDoj(String doj) {
	this.doj = doj;
}
public String getAggDate() {
	return AggDate;
}
public void setAggDate(String aggDate) {
	AggDate = aggDate;
}
public String getManagerDetails() {
	return managerDetails;
}
public void setManagerDetails(String managerDetails) {
	this.managerDetails = managerDetails;
}
public String getEmail() {
	return Email;
}
public void setEmail(String email) {
	Email = email;
}
public int getNumEmp() {
	return numEmp;
}
public void setNumEmp(int numEmp) {
	this.numEmp = numEmp;
}


	
	
}

package com.itManage.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.itManage.DaoConn.ServiceDao;
import com.itManage.model.Department;
import com.itManage.model.Divitions;

/**
 * Servlet implementation class GetDepNames
 */
@WebServlet("/GetDepNames")
public class GetDepNames extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetDepNames() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    String action =null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		ServiceDao dao=new ServiceDao();
		List<Department> depList=new ArrayList<Department>();
		try {  
			if(action.equals("null")){
		           depList=dao.findAll();

		          
		         
		   		response.setContentType("application/json");

		           Gson gson = new Gson();
		           
		          JSONROOT.put("Result", "OK");
					JSONROOT.put("Records", depList);
					String jsonNames = gson.toJson(JSONROOT);
										
					response.getWriter().print(jsonNames);
			
		} 
			else
			{ 
				Department dept = new Department();
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				if (action.equals("update")) {
					
					String dep_id=request.getParameter("dep_id");
					dept.setDep_id(Integer.parseInt(dep_id));
					dept.setDiv_name(request.getParameter("div_name"));
					dept.setName(request.getParameter("name"));
					dept.setStatus(1);
					System.out.println("div");
					dao.updateDept(dept);
					// Return in the format required by jTable plugin
					JSONROOT.put("Result", "OK");
					JSONROOT.put("Record", dept);

					// Convert Java Object to Json
					String jsonArray = gson.toJson(JSONROOT);
					response.getWriter().print(jsonArray);
				}
			 else if (action.equals("delete")) {
				if (request.getParameter("dep_id") != null) {
					int dep_id = Integer.parseInt(request.getParameter("dep_id"));					
					dao.deleteDept(dep_id);
					JSONROOT.put("Result", "OK");	   
					String jsonArray = gson.toJson(JSONROOT);
					response.getWriter().print(jsonArray);
				}
		
			}
			}
		}catch (Exception e) {
			// TODO: handle exception
			System.out.print(e);
		}
		

		
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//String	name= request.getParameter("divName");

		//System.out.println(name);
		 action = request.getParameter("action");
		doGet(request, response);
	}

}

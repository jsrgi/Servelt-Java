package com.itManage.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.itManage.DaoConn.ServiceDao;
import com.itManage.model.Complaint;

@WebServlet("/ViewComDet")
public class ViewComDet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();
    
    public ViewComDet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String empid=request.getParameter("empId");
		//String empid="emp003";
		System.out.println(empid);
		ServiceDao provide=new ServiceDao();
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		List<Complaint> comList = new ArrayList<Complaint>();
		try {
			comList=provide.getEmpComplaint(empid);
			JSONROOT.put("Result", "OK");
			JSONROOT.put("Records", comList);

			String jsonArray = gson.toJson(JSONROOT);

			response.getWriter().print(jsonArray);
			System.out.println(jsonArray);
			
		} catch (Exception e) {
			System.err.println(e);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

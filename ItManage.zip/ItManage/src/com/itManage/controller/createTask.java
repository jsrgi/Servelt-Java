package com.itManage.controller;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.itManage.DaoConn.ServiceDao;
import com.itManage.model.Task;
import com.itMange.db.DbConnection;
import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class createTask
 */
@WebServlet("/createTask")
public class createTask extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public createTask() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		String createName = (String) session.getAttribute("name");
		System.out.println(createName);
		Connection conn = null;
		Task task = null;
		ServiceDao dao = null;
		int create_id = 0;
		try {
			
			dao = new ServiceDao();

			//create_id = dao.findEmpId(createName);

			task = new Task();
			 int pro_id=Integer.parseInt(request.getParameter("sProject"));
			 
			//int pro_id = dao.pro_id(name);
			 String pro_name=dao.getPname(pro_id).trim();
			conn = DbConnection.getSqlConnection();
			task.setP_name(pro_name);
			
			task.setT_name(request.getParameter("tname").trim());
			task.setPro_id(pro_id);
			task.setT_des(request.getParameter("tdes").trim());
			task.setCreate(createName);
			
			PreparedStatement pst = (PreparedStatement) conn.prepareStatement(
					"insert into addtask  (task_name,p_id,p_name,t_emp,t_des) values (?,?,?,?,?)");

			pst.setString(1, task.getT_name());
			pst.setInt(2, task.getPro_id());
			pst.setString(3, task.getP_name());		
			pst.setString(4, task.getCreate());
			pst.setString(5, task.t_des);
			
			pst.execute();
			pst.close();

			conn.close();
			response.sendRedirect("AddTask.html");
			//request.getRequestDispatcher("AddTask.html").include(request, response);

		} catch (Exception e) {
			System.out.println(e);// TODO: handle exception
		}

		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.itManage.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.itManage.DaoConn.ServiceDao;
import com.itManage.model.Client;
import com.itManage.model.Employee;
import com.itMange.db.DbConnection;



/**
 * Servlet implementation class NewEmployee
 */
@WebServlet("/AddClient")
public class AddClient extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddClient() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection conn = null;
		Client client = null;
		
		String action = request.getParameter("action");
		
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		response.setContentType("application/json");
		List<Client> empList=new ArrayList<Client>();
		//String action="list";
		ServiceDao dao=new ServiceDao();
		if (action==null)
		{
			action="create";
		}
		if(action!=null)
		{
			
		
			try { 
				
				if(action.equals("list"))
				{
					empList=ServiceDao.clientAll();

					JSONROOT.put("Result", "OK");
					JSONROOT.put("Records", empList);

					String jsonArray = gson.toJson(JSONROOT);

					response.getWriter().print(jsonArray);
				
				}
				else if(action.equals("create") || action.equals("update") )
				{
				
		
			client = new Client();
			conn = DbConnection.getSqlConnection();
			client.setClientName(request.getParameter("clientName"));
			client.setClientDescription(request.getParameter("ClientDescription"));
			client.setDoj(request.getParameter("doj"));
			client.setAggDate(request.getParameter("AggDate"));
			client.setProjectDetails(request.getParameter("ProjectDetails"));
			client.setEmail(request.getParameter("Email"));
			client.setAddress(request.getParameter("address"));
			
             
			PreparedStatement pst=null;
			if (action.equals("create")){
			pst = conn.prepareStatement(
					"insert into client(clientName,ClientDescription,doj,AggDate,ProjectDetails,Email,address) values(?,?,?,?,?,?,?)");

			pst.setString(1, client.getClientName());
			pst.setString(2, client.getClientDescription());
			pst.setString(3, client.getDoj());
			pst.setString(4, client.getAggDate());
			pst.setString(5, client.getProjectDetails());
			pst.setString(6, client.getEmail());
			pst.setString(7, client.getAddress());
			pst.execute();
			pst.close();			
      		conn.close();
      		//System.out.println("Test IF");
      		response.sendRedirect("AddClient.html");
      		//request.getRequestDispatcher("AddClient.html").include(request, response);
			}
			else if (action.equals("update")) {
				String client_id=request.getParameter("client_id");
				client.setClient_id(Integer.parseInt(client_id));
				dao.updateClient(client);
				// Return in the format required by jTable plugin
				JSONROOT.put("Result", "OK");
				JSONROOT.put("Record", client);

				// Convert Java Object to Json
				String jsonArray = gson.toJson(JSONROOT);
				response.getWriter().print(jsonArray);
			}
		} else if (action.equals("delete")) {
			if (request.getParameter("client_id") != null) {
				int client_id = Integer.parseInt(request.getParameter("client_id"));
				
				dao.deleteClient(client_id);
				JSONROOT.put("Result", "OK");
   
				String jsonArray = gson.toJson(JSONROOT);
				response.getWriter().print(jsonArray);
			}
		
	}
				
				}
			catch (Exception e) {

			System.out.println(e);
			// TODO: handle exception
		}

		}}
	
}

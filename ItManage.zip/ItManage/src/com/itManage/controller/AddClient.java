package com.itManage.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itManage.model.Client;
import com.itMange.db.DbConnection;



/**
 * Servlet implementation class NewEmployee
 */
@WebServlet("/AddClient")
public class AddClient extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddClient() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection conn = null;
		Client client = null;
		
		try {
			
		
			client = new Client();
			conn = DbConnection.getSqlConnection();
			client.setClientName(request.getParameter("clientName"));
			client.setClientDescription(request.getParameter("ClientDescription"));
			client.setDoj(request.getParameter("doj"));
			client.setAggDate(request.getParameter("AggDate"));
			client.setProjectDetails(request.getParameter("ProjectDetails"));
			client.setEmail(request.getParameter("Email"));
			client.setAddress(request.getParameter("address"));
			
             
			PreparedStatement pst = conn.prepareStatement(
					"insert into client(clientName,ClientDescription,doj,AggDate,ProjectDetails,Email,address) values(?,?,?,?,?,?,?)");

			pst.setString(1, client.getClientName());
			pst.setString(2, client.getClientDescription());
			pst.setString(3, client.getDoj());
			pst.setString(4, client.getAggDate());
			pst.setString(5, client.getProjectDetails());
			pst.setString(6, client.getEmail());
			pst.setString(7, client.getAddress());
			
			

			pst.execute();
			pst.close();
			
      		conn.close();

			
			
      		request.getRequestDispatcher("AddClient.html").include(request, response);
			

		} catch (Exception e) {

			System.out.println(e);
			// TODO: handle exception
		}

	}

}

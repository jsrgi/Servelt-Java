package com.itManage.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.itManage.DaoConn.ServiceDao;
import com.itManage.model.Task;


/**
 * Servlet implementation class ViewProject
 */
@WebServlet("/viewTask")
public class viewTask extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();

    /**
     * @see HttpServlet#HttpServlet()
     */
    public viewTask() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		String action = request.getParameter("action");
		String pro_id= (String) request.getSession().getAttribute("project_id");
		System.out.println(request.getSession().getAttribute("project_id"));
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		response.setContentType("application/json");
		List<Task> proList=new ArrayList<Task>();
		//String action="list";
		ServiceDao dao=new ServiceDao();
		if(action!=null)
		{
			
		
			try {   
				if(action.equals("list"))
				{
					proList=ServiceDao.taskAll(pro_id);

					JSONROOT.put("Result", "OK");
					JSONROOT.put("Records", proList);

					String jsonArray = gson.toJson(JSONROOT);

					response.getWriter().print(jsonArray);
					
				
				}
				else if (action.equals("update")) {
					Task pro=new Task();
					
					
					if (request.getParameter("t_des") != null) {
						pro.setT_des(request.getParameter("t_des"));
					}
					if (request.getParameter("t_name") != null) {
						pro.setT_name(request.getParameter("t_name"));
					}
					if (request.getParameter("t_id") != null) {
						pro.setT_id(Integer.parseInt(request.getParameter("t_id")));
					}
					dao.updateTask(pro);
					

					// Return in the format required by jTable plugin
					JSONROOT.put("Result", "OK");
					JSONROOT.put("Record", pro);

					// Convert Java Object to Json
					String jsonArray = gson.toJson(JSONROOT);
					response.getWriter().print(jsonArray);
				}
				else if (action.equals("delete")) {
					if (request.getParameter("t_id") != null) {
						int pro_id1 = Integer.parseInt(request.getParameter("t_id"));
						
						dao.deleteTask(pro_id1);
						JSONROOT.put("Result", "OK");
           
						String jsonArray = gson.toJson(JSONROOT);
						response.getWriter().print(jsonArray);
					}
				
			}
				}
			catch (Exception e) {
				System.out.println(e);// TODO: handle exception
			}
		}
		//doGet(request, response);
	}

}

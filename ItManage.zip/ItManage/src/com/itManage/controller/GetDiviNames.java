package com.itManage.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.itManage.DaoConn.ServiceDao;
import com.itManage.model.Client;
import com.itManage.model.Divitions;


/**
 * Servlet implementation class GetDivi
 */
@WebServlet("/GetDivi")
public class GetDiviNames extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HashMap<String, Object> JSONROOT = new HashMap<String, Object>();

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetDiviNames() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	String action =null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ServiceDao dao=new ServiceDao();
		List<Divitions> divList=new ArrayList<Divitions>();
		
		try {    
			if(action.equals("null")){
		           divList=dao.getAll();
		   		response.setContentType("application/json");

		           Gson gson = new Gson();  
		          JSONROOT.put("Result", "OK");
					JSONROOT.put("Records", divList);
					String jsonNames = gson.toJson(JSONROOT);				
					response.getWriter().print(jsonNames);
			
		}
			else
			{ 
				Divitions div = new Divitions();
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				if (action.equals("update")) {
					
					String client_id=request.getParameter("div_id");
					div.setDiv_id(Integer.parseInt(client_id));
					div.setDiv_name(request.getParameter("div_name"));
					System.out.println("div");
					dao.updateDiv(div);
					// Return in the format required by jTable plugin
					JSONROOT.put("Result", "OK");
					JSONROOT.put("Record", div);

					// Convert Java Object to Json
					String jsonArray = gson.toJson(JSONROOT);
					response.getWriter().print(jsonArray);
				}
			 else if (action.equals("delete")) {
				if (request.getParameter("div_id") != null) {
					int div_id = Integer.parseInt(request.getParameter("div_id"));					
					dao.deleteDiv(div_id);
					JSONROOT.put("Result", "OK");	   
					String jsonArray = gson.toJson(JSONROOT);
					response.getWriter().print(jsonArray);
				}
		
			}
		}
		}catch (Exception e) {
			// TODO: handle exception
			System.out.print(e);
		}
		
			}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 action = request.getParameter("action");
		doGet(request, response);
	}

}

-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2019 at 06:10 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `itmanagement`
--

-- --------------------------------------------------------

--
-- Table structure for table `addtask`
--

CREATE TABLE `addtask` (
  `t_id` bigint(30) NOT NULL,
  `task_name` varchar(100) NOT NULL,
  `t_des` varchar(100) NOT NULL,
  `t_emp` varchar(30) NOT NULL,
  `p_id` bigint(30) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `t_status` int(11) NOT NULL DEFAULT '1',
  `t_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addtask`
--

INSERT INTO `addtask` (`t_id`, `task_name`, `t_des`, `t_emp`, `p_id`, `p_name`, `t_status`, `t_time`) VALUES
(1, 'test', '', '12', 1, 'asset', 1, '2019-02-09 15:06:03'),
(2, 'create login page for employees', 'create login page', 'mohan', 14, 'Assest Management System', 1, '2019-02-09 15:19:10'),
(3, 'createTask', 'createTask', 'mohan', 14, 'Assest Management System', 0, '2019-02-09 16:46:28'),
(4, 'Create LMS process', 'Create LMS process including leave apply, cancel and update procedures.', 'mohan', 14, 'Assest Management System', 1, '2019-02-12 15:25:26'),
(5, 'createTask', 'createTask', 'mohan', 14, 'Assest Management System', 1, '2019-02-21 15:55:27'),
(6, 'createTask', 'hardware', 'mohan', 14, 'Assest Management System', 1, '2019-02-23 07:34:35'),
(7, 'createTask', 'good', 'mohan', 14, 'Assest Management System', 1, '2019-03-02 08:45:03'),
(8, 'createTask', 'fine', 'mohan', 14, 'Assest Management System', 1, '2019-03-02 13:20:57');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` int(11) NOT NULL,
  `clientName` varchar(50) NOT NULL,
  `ClientDescription` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `doj` varchar(10) NOT NULL,
  `AggDate` varchar(10) NOT NULL,
  `ProjectDetails` varchar(150) NOT NULL,
  `address` varchar(150) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `clientName`, `ClientDescription`, `Email`, `doj`, `AggDate`, `ProjectDetails`, `address`, `status`, `created_at`) VALUES
(1, 'Siemes ltd', 'testing and dev', 'Siem@gmail.com', '12/12/2018', '12/12/2019', 'siemnse', 'bangalore', 1, '2019-02-02 09:01:47'),
(2, 'Siemens', 'Developement team', 'Siem@gmail.com', '2019-02-02', '2020-03-25', 'Siemens', 'Bangalore', 0, '2019-02-02 16:26:46'),
(3, 'Bosch', 'Manufacturing company', 'hr@bosch.com', '2019-02-03', '2019-04-18', 'BOsch limited', 'Keeranatham, coimbatore-641035', 1, '2019-02-03 12:52:27'),
(4, 'Cognizant', 'Service basedcompany', 'hr@cts.com', '2019-02-03', '2019-04-18', 'cognizantlimited', 'Keeranatham, coimbatore-641035', 1, '2019-02-03 12:55:59'),
(5, 'NTT', 'Medical code oriented', 'hr@ntt.com', '2019-02-03', '2020-01-03', 'NTT limited', 'Keeranatham, coimbaore', 1, '2019-02-03 13:00:00'),
(6, 'EDA', 'Executive digital assistance', 'contacthr@eda.com', '2019-02-03', '2022-12-12', 'Siemens', 'Canada.', 1, '2019-02-03 13:04:08'),
(7, 'test client', 'test', 'hr@cts.com', '2019-02-03', '2019-02-28', 'BOsch limited', 'test', 0, '2019-02-03 13:05:22'),
(8, 'test client', 'Executive digital assistance', 'contacthr@eda.com', '2019-02-03', '2019-02-28', 'Siemens', 'test', 0, '2019-02-03 13:08:15'),
(9, 'Cognizant', 'test', 'hr@bosch.com', '2019-02-03', '2019-02-13', 'NTT limited', '', 0, '2019-02-03 13:10:30'),
(10, 'Cognizant', 'test', 'hr@bosch.com', '2019-02-03', '2019-02-13', 'NTT limited', '', 0, '2019-02-03 13:12:05'),
(11, 'karthik', 'Developement team', 'arun@siemens.com', '2019-02-06', '2020-02-14', 'NTT limited', 'tirupur', 1, '2019-02-23 07:30:07'),
(12, 'Cognizant123', 'Developement team', 'Siem@gmail.com', '2019-03-10', '2019-03-30', 'To create a software and hardware installation', 'keeranatham', 1, '2019-03-10 06:49:21');

-- --------------------------------------------------------

--
-- Table structure for table `comtable`
--

CREATE TABLE `comtable` (
  `comId` int(11) NOT NULL,
  `empId` varchar(15) NOT NULL,
  `empName` varchar(25) NOT NULL,
  `comType` varchar(30) NOT NULL,
  `comDesc` varchar(250) NOT NULL,
  `comRecDt` date NOT NULL,
  `comTarDt` date NOT NULL,
  `comStat` varchar(50) NOT NULL DEFAULT 'complainted',
  `comStatus` int(11) NOT NULL DEFAULT '1',
  `comCreateAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comtable`
--

INSERT INTO `comtable` (`comId`, `empId`, `empName`, `comType`, `comDesc`, `comRecDt`, `comTarDt`, `comStat`, `comStatus`, `comCreateAt`) VALUES
(1, '74', 'mohan', 'Check', 'test entry', '2019-02-10', '2019-02-21', 'complainted', 1, '2019-02-10 06:55:59'),
(2, '74', 'mohan', 'Again test', 'test entry', '2019-02-10', '2019-02-24', 'complainted', 1, '2019-02-10 06:57:10'),
(3, '74', 'mohan', 'Again test', 'test entry', '2019-02-10', '2019-02-24', 'complainted', 1, '2019-02-10 07:09:53'),
(4, '77', 'madhu', 'test', 'test from employee', '2019-02-10', '2019-02-23', 'complainted', 1, '2019-02-10 07:57:42'),
(5, '77', 'madhu', 'test', '', '2019-02-10', '2019-02-13', 'complainted', 1, '2019-02-10 08:03:27'),
(6, '77', 'madhu', 'sdfd', 'dfsdf', '2019-02-10', '2019-02-13', 'complainted', 1, '2019-02-10 08:04:57'),
(7, '77', 'madhu', 'sdfd', 'dfsdf', '2019-02-10', '2019-02-13', 'complainted', 1, '2019-02-10 08:05:57'),
(8, '77', 'madhu', 'fgdfgdfg', 'dfsdfsdf', '2019-02-06', '2019-02-14', 'complainted', 1, '2019-02-10 08:06:19'),
(9, '77', 'madhu', 'sfsdfsdf', '', '2019-02-06', '2019-02-15', 'complainted', 1, '2019-02-10 08:06:36');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dep_id` bigint(30) NOT NULL,
  `dep_name` varchar(30) NOT NULL,
  `dep_status` int(11) NOT NULL DEFAULT '1',
  `dep_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `div_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dep_id`, `dep_name`, `dep_status`, `dep_time`, `div_name`) VALUES
(9, 'GSS', 1, '2018-03-31 13:07:23', 'IT-CSE'),
(10, 'RND', 1, '2018-03-31 13:10:58', 'IT-CSE'),
(11, 'voice', 1, '2018-03-31 13:12:02', 'IT'),
(12, 'GSS', 1, '2018-03-31 17:16:44', 'NON-IT'),
(13, 'Voice', 1, '2018-03-31 17:20:28', 'NON-IT'),
(14, 'client', 1, '2018-03-31 17:44:29', 'NON-IT'),
(15, 'Gss', 0, '2018-03-31 17:47:20', 'KGISL'),
(16, 'Voice', 0, '2018-03-31 17:47:53', 'KGISL'),
(17, 'check department', 1, '2019-02-02 09:09:13', 'Demo'),
(18, 'BPO', 1, '2019-02-03 13:37:33', 'IT'),
(19, 'Test', 1, '2019-02-21 15:38:49', 'demo'),
(20, 'test', 1, '2019-02-21 18:42:27', 'demo'),
(21, 'Test', 0, '2019-02-21 18:47:24', 'demo'),
(22, 'Check dept', 1, '2019-02-23 05:55:58', 'Check'),
(23, 'it', 1, '2019-02-28 12:31:13', 'TCS'),
(24, 'css', 1, '2019-02-28 15:50:24', 'IT-CSE'),
(25, 'csss', 1, '2019-02-28 15:50:40', 'new');

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

CREATE TABLE `division` (
  `div_id` bigint(20) NOT NULL,
  `div_name` varchar(30) NOT NULL,
  `div_status` int(11) NOT NULL DEFAULT '1',
  `div_createAt` varchar(30) NOT NULL DEFAULT 'admin',
  `div_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`div_id`, `div_name`, `div_status`, `div_createAt`, `div_time`) VALUES
(5, 'IT-CSE', 1, 'admin', '2018-03-31 11:42:00'),
(6, 'NON-IT', 1, 'admin', '2018-03-31 12:31:21'),
(7, 'KGISL', 0, 'admin', '2018-03-31 12:37:37'),
(8, 'KGFSL', 0, 'admin', '2018-03-31 12:44:37'),
(9, 'TCS', 1, 'admin', '2018-03-31 13:06:34'),
(16, 'new', 1, 'admin', '2018-04-11 04:52:48'),
(17, 'Demo', 0, 'admin', '2019-02-02 09:08:58'),
(18, 'demo', 1, 'admin', '2019-02-03 13:35:11'),
(19, 'AVM', 1, 'admin', '2019-02-03 13:36:52'),
(20, 'AVD', 1, 'admin', '2019-02-03 14:24:41'),
(21, 'Check', 1, 'admin', '2019-02-23 05:55:31');

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE `emp` (
  `emp_id` bigint(30) NOT NULL,
  `emp_idNum` varchar(10) NOT NULL,
  `emp_fname` varchar(30) NOT NULL,
  `emp_lname` varchar(30) NOT NULL,
  `emp_gender` varchar(20) NOT NULL,
  `emp_dob` varchar(10) NOT NULL,
  `emp_doj` varchar(10) NOT NULL,
  `emp_email` varchar(35) NOT NULL,
  `emp_desiganation` varchar(25) NOT NULL,
  `emp_division` varchar(20) NOT NULL,
  `emp_department` varchar(20) NOT NULL,
  `emp_team` varchar(20) NOT NULL,
  `address` varchar(150) NOT NULL,
  `emp_uname` varchar(30) NOT NULL,
  `emp_pass` varchar(30) NOT NULL,
  `emp_status` int(11) NOT NULL DEFAULT '1',
  `emp_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp`
--

INSERT INTO `emp` (`emp_id`, `emp_idNum`, `emp_fname`, `emp_lname`, `emp_gender`, `emp_dob`, `emp_doj`, `emp_email`, `emp_desiganation`, `emp_division`, `emp_department`, `emp_team`, `address`, `emp_uname`, `emp_pass`, `emp_status`, `emp_time`) VALUES
(70, 'IT01', 'Aravind', 'Kumar', 'male', '1997-05-01', '2018-03-30', 'madhu@gmail.com', 'manager', 'IT', 'GSS', 'Testing', '39,ganthinagar,palani,dindugul', 'aravind', 'Aravind123', 1, '2018-03-31 18:02:10'),
(71, 'IT02', 'Akil', 'tangavel', 'Male', '1997-03-06', '2018-03-30', 'akilh4@gmail.com', 'team leader', 'IT', 'GSS', 'Testing', 'Palani', 'akil', 'Akil1234', 1, '2018-03-31 18:04:30'),
(72, 'IT03', 'Soundar', 'Rajan', 'male', '1996-03-06', '2018-03-30', 'haifriends1997@gmail.com', 'employee', 'IT', 'GSS', 'Testing', 'kovai1', 'soundar', 'Soundar12345', 1, '2018-03-31 18:12:28'),
(73, 'IT04', 'elango', 'elango', 'male', '1996-01-02', '2018-03-30', 'haifriends1997@gmail.com', 'employee', 'IT', 'GSS', 'Design', 'kovai', 'elango', 'Elango1234', 1, '2018-03-31 18:13:44'),
(74, 'NON01', 'Mohan', 'siva', 'male', '1996-02-05', '2018-03-31', 'mohan@gmail.com', 'manager', 'NON-IT', 'GSS', 'Testing', 'kovai', 'mohan', 'Mohan1234', 1, '2018-04-01 13:16:51'),
(75, 'NON02', 'suresh', 'kumar', 'male', '1997-01-02', '2018-04-01', 'suresh@gmail.com', 'team leader', 'NON-IT', 'GSS', 'Testing', 'kovai', 'suresh', 'Suresh1234', 1, '2018-04-01 13:20:13'),
(76, 'NON03', 'gayatri', 'gayatri', 'female', '1997-02-05', '2018-04-01', 'gayatri@gmail.com', 'employee', 'NON-IT', 'GSS', 'Testing', 'kovai', 'gayatri', 'Gayatri1234', 1, '2018-04-01 13:23:44'),
(77, 'NON04', 'Srimathi', 'sri', 'female', '2018-04-05', '2018-04-01', 'madhu@gmail.com', 'employee', 'NON-IT', 'GSS', 'Testing', 'Coimbatore', 'madhu', 'M@thiit8', 1, '2018-04-01 13:29:09'),
(78, 'AO1', 'a', 'a', 'female', '2018-04-05', '2018-04-10', 'sri@gmail.com', 'manager', 'NON-IT', 'GSS', 'Testing', 'kovai', 'sri', 'Sri12345', 0, '2018-04-10 09:28:14'),
(79, 'emp00003', 'priya', 'dharshini', 'female', '1997-02-13', '2019-02-21', 'priya@gmail.com', 'manager', 'IT-CSE', 'GSS', 'Design', 'kovai', 'priya', 'Priya@123', 1, '2019-02-23 07:28:04');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `pro_id` bigint(30) NOT NULL,
  `p_name` varchar(30) NOT NULL,
  `p_des` varchar(50) NOT NULL,
  `createEmp_id` bigint(30) NOT NULL,
  `doj` varchar(30) NOT NULL,
  `AggDate` varchar(30) NOT NULL,
  `managerDetails` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `numEmp` bigint(30) NOT NULL,
  `p_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `p_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`pro_id`, `p_name`, `p_des`, `createEmp_id`, `doj`, `AggDate`, `managerDetails`, `Email`, `numEmp`, `p_time`, `p_status`) VALUES
(1, 'IT management', 'To create all process for project assigning', 71, '', '', '', '', 0, '2018-04-05 13:18:40', 1),
(2, 'Assest Management System', 'To create a software and hardware installation', 71, '', '', '', '', 0, '2018-04-05 13:22:25', 1),
(3, 'LabtopShopManagement', 'To create all procee', 71, '', '', '', '', 0, '2018-04-07 05:37:35', 1),
(4, 'Student Information System', 'Student Information System', 71, '', '', '', '', 0, '2018-04-07 11:39:13', 1),
(6, 'hardware management', 'To create a hardware management system .', 71, '', '', '', '', 0, '2018-04-09 05:27:07', 1),
(11, 'software Management', 'To create software Management', 71, '', '', '', '', 0, '2018-04-09 05:33:41', 1);

-- --------------------------------------------------------

--
-- Table structure for table `project1`
--

CREATE TABLE `project1` (
  `pro_id` bigint(30) NOT NULL,
  `p_name` varchar(30) NOT NULL,
  `p_des` varchar(50) NOT NULL,
  `createEmp_id` bigint(30) NOT NULL,
  `doj` varchar(30) NOT NULL,
  `AggDate` varchar(30) NOT NULL,
  `managerDetails` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `numEmp` bigint(30) NOT NULL,
  `p_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `p_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project1`
--

INSERT INTO `project1` (`pro_id`, `p_name`, `p_des`, `createEmp_id`, `doj`, `AggDate`, `managerDetails`, `Email`, `numEmp`, `p_time`, `p_status`) VALUES
(13, 'Nexus MyOneIT', 'Handle workflow', 1, '2019-02-03', '2021-12-28', 'Arun venkatesh', 'arun@siemens.com', 18, '2019-02-03 15:23:28', 1),
(14, 'Assest Management System', 'To create a software and hardware installation', 1, '2019-02-03', '2022-02-22', 'Arun venkatesh', 'contacthr@eda.com', 30, '2019-02-03 15:27:20', 1),
(15, 'LabtopShopManagement', 'To create all procee', 1, '2019-02-03', '2029-02-03', 'madhumathi V', 'madhu@cts.com', 24, '2019-02-03 15:28:25', 1),
(16, 'tata', 'Handle workflow', 1, '2019-02-12', '2019-02-28', 'madhumathi V', 'arun@siemens.com', 12, '2019-02-23 07:32:41', 1);

-- --------------------------------------------------------

--
-- Table structure for table `projectempdetail`
--

CREATE TABLE `projectempdetail` (
  `d_id` bigint(30) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `emp_name` varchar(30) NOT NULL,
  `emp_role` varchar(30) NOT NULL,
  `pro_id` bigint(30) NOT NULL,
  `d_status` int(11) NOT NULL DEFAULT '1',
  `d_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projectempdetail`
--

INSERT INTO `projectempdetail` (`d_id`, `emp_id`, `emp_name`, `emp_role`, `pro_id`, `d_status`, `d_time`) VALUES
(1, 72, 'Soundar', 'Testing', 13, 1, '2018-04-05 13:18:40'),
(2, 73, 'elango', 'Design', 13, 1, '2018-04-05 13:18:40'),
(3, 72, 'Soundar', 'Testing', 14, 1, '2018-04-05 13:22:25'),
(4, 73, 'elango', 'Design', 14, 1, '2018-04-05 13:22:25'),
(5, 72, 'Soundar', 'Testing', 14, 1, '2018-04-07 05:37:35'),
(6, 73, 'elango', 'Design', 14, 1, '2018-04-07 05:37:35'),
(12, 73, 'elango', 'Design', 14, 1, '2018-04-09 05:27:07'),
(13, 72, 'Soundar', 'Testing', 7, 1, '2018-04-09 05:30:14'),
(14, 73, 'elango', 'Design', 7, 1, '2018-04-09 05:30:14'),
(15, 72, 'Soundar', 'Testing', 8, 1, '2018-04-09 05:30:59'),
(16, 73, 'elango', 'Design', 8, 1, '2018-04-09 05:30:59'),
(17, 72, 'Soundar', 'Testing', 9, 1, '2018-04-09 05:31:20'),
(18, 73, 'elango', 'Design', 9, 1, '2018-04-09 05:31:20'),
(19, 72, 'Soundar', 'Testing', 10, 1, '2018-04-09 05:31:32'),
(20, 77, 'madhu', 'Design', 14, 1, '2018-04-09 05:31:33'),
(21, 72, 'Soundar', 'Testing', 11, 1, '2018-04-09 05:33:41'),
(22, 73, 'elango', 'Design', 11, 1, '2018-04-09 05:33:41'),
(23, 74, 'mohan', 'manager', 14, 1, '2019-02-09 10:19:15');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `task_id` bigint(30) NOT NULL,
  `t_name` varchar(30) NOT NULL,
  `pro_id` bigint(30) NOT NULL,
  `p_name` varchar(35) NOT NULL,
  `t_des` varchar(100) NOT NULL,
  `t_createAt` varchar(30) NOT NULL,
  `t_assignee` varchar(30) DEFAULT NULL,
  `task_status` varchar(30) NOT NULL,
  `t_sdate` varchar(10) NOT NULL,
  `t_ddate` varchar(10) NOT NULL,
  `t_status` int(11) NOT NULL DEFAULT '1',
  `t_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `task_id`, `t_name`, `pro_id`, `p_name`, `t_des`, `t_createAt`, `t_assignee`, `task_status`, `t_sdate`, `t_ddate`, `t_status`, `t_time`) VALUES
(1, 4, 'Create LMS process', 14, 'Assest Management System', 'LMS process to create', 'mohan', '77', 'Testing', '2019-02-12', '2019-02-28', 1, '2019-02-12 15:39:18'),
(2, 5, 'createTask', 14, 'Assest Management System', 'Create Task', 'mohan', '77', 'Client clarification', '2019-02-21', '2019-02-28', 1, '2019-02-21 15:56:00'),
(3, 6, 'createTask', 14, 'Assest Management System', 'none', 'mohan', '72', 'Testing', '2019-02-15', '2019-02-28', 1, '2019-02-23 07:36:11'),
(4, 4, 'Create LMS process', 14, 'Assest Management System', 'good', 'mohan', '73', 'Testing', '2019-03-07', '2020-09-01', 1, '2019-03-02 08:50:44');

-- --------------------------------------------------------

--
-- Table structure for table `task_update`
--

CREATE TABLE `task_update` (
  `u_id` bigint(30) NOT NULL,
  `pro_id` bigint(30) NOT NULL,
  `t_id` bigint(30) NOT NULL,
  `u_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `u_empid` int(30) NOT NULL,
  `u_priority` int(11) NOT NULL,
  `u_days` int(11) NOT NULL,
  `u_response` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task_update`
--

INSERT INTO `task_update` (`u_id`, `pro_id`, `t_id`, `u_time`, `u_empid`, `u_priority`, `u_days`, `u_response`) VALUES
(0, 14, 4, '2019-02-12 17:27:02', 0, 4, 12, 'Test entry'),
(1, 2, 3, '2018-04-05 14:25:49', 0, 1, 10, 'Its easy to create'),
(2, 1, 1, '2018-04-05 14:27:25', 0, 1, 1, 'Its easy'),
(3, 2, 4, '2018-04-05 14:36:36', 73, 1, 2, 'Its easy'),
(4, 2, 4, '2018-04-05 14:37:16', 73, 1, 1, 'Its easy one'),
(5, 1, 1, '2018-04-09 18:14:37', 0, 1, 1, 'easy'),
(6, 2, 3, '2018-04-09 18:14:59', 0, 1, 1, 'easy'),
(8, 14, 4, '2019-02-12 17:18:35', 0, 4, 5, 'Added username and pasword fields with validation under \\it company policies'),
(10, 2, 4, '2019-02-12 17:30:37', 0, 4, 1, 'test'),
(11, 2, 5, '2019-02-21 15:56:53', 0, 4, 2, ''),
(12, 14, 4, '2019-02-21 17:28:44', 0, 4, 3, 'Test entry to check history'),
(13, 14, 4, '2019-02-21 18:28:45', 74, 4, 12, '<strong>Adding history from TL</strong>'),
(14, 2, 4, '2019-02-12 17:18:21', 0, 4, 5, 'Added username and pasword fields with validation under \\it company policies'),
(15, 14, 5, '2019-02-21 18:37:12', 74, 4, 12, 'Client involvement need This icket is moved to Level 1 team members for furthur.'),
(16, 14, 6, '2019-02-23 07:40:31', 74, 3, 3, '<em><strong>You have to completed</strong></em>');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `t_id` bigint(30) NOT NULL,
  `t_name` varchar(30) NOT NULL,
  `t_status` int(11) NOT NULL DEFAULT '1',
  `dep_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`t_id`, `t_name`, `t_status`, `dep_name`) VALUES
(7, 'Testing', 1, 'GSS'),
(8, 'Design', 1, 'GSS'),
(9, 'Design', 1, 'RND'),
(10, 'design', 1, 'Voice'),
(11, 'Testing', 1, 'Voice'),
(12, 'design', 1, 'client'),
(13, 'design', 1, 'Gss'),
(14, 'test', 1, 'Gss'),
(15, 'team1', 1, 'new'),
(16, 'team2', 1, 'new'),
(17, 'testing', 1, 'RND'),
(18, 'check team', 1, 'check'),
(19, 'Development', 1, 'GSS'),
(20, 'CR', 1, 'Test'),
(21, 'check team', 1, 'Check'),
(22, 'testing', 1, 'select'),
(23, 'implement', 1, 'Voice'),
(24, 'testing and impleemntation', 1, 'it'),
(25, 'testing', 1, 'csss');

-- --------------------------------------------------------

--
-- Table structure for table `user_account`
--

CREATE TABLE `user_account` (
  `user_id` bigint(20) NOT NULL,
  `emp_id` bigint(30) NOT NULL,
  `user_name` varchar(25) NOT NULL,
  `user_password` varchar(25) NOT NULL,
  `user_role` varchar(11) NOT NULL,
  `user_status` int(11) NOT NULL DEFAULT '1',
  `user_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_createAt` varchar(30) NOT NULL DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_account`
--

INSERT INTO `user_account` (`user_id`, `emp_id`, `user_name`, `user_password`, `user_role`, `user_status`, `user_time`, `user_createAt`) VALUES
(71, 70, 'aravind', 'Aravind123', 'manager', 1, '2018-03-31 18:02:10', 'admin'),
(72, 71, 'akil', 'Akil1234', 'team leader', 1, '2018-03-31 18:04:31', 'admin'),
(73, 72, 'soundar', 'Soundar12345', 'employee', 1, '2018-03-31 18:12:28', 'admin'),
(74, 73, 'elango', 'Elango1234', 'employee', 1, '2018-03-31 18:13:44', 'admin'),
(75, 74, 'mohan', '123', 'manager', 1, '2018-04-01 13:16:52', 'admin'),
(76, 75, 'suresh', 'Suresh1234', 'team leader', 1, '2018-04-01 13:20:14', 'admin'),
(77, 76, 'gayatri', 'Gayatri1234', 'employee', 1, '2018-04-01 13:23:44', 'admin'),
(78, 77, 'madhu', '123', 'employee', 1, '2018-04-01 13:29:09', 'admin'),
(79, 78, 'sri', 'Sri12345', 'manager', 0, '2018-04-10 09:28:14', 'admin'),
(80, 79, 'priya', 'Priya@123', 'manager', 1, '2019-02-23 07:28:04', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addtask`
--
ALTER TABLE `addtask`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `comtable`
--
ALTER TABLE `comtable`
  ADD PRIMARY KEY (`comId`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dep_id`);

--
-- Indexes for table `division`
--
ALTER TABLE `division`
  ADD PRIMARY KEY (`div_id`);

--
-- Indexes for table `emp`
--
ALTER TABLE `emp`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`pro_id`),
  ADD KEY `createEmp_id` (`createEmp_id`);

--
-- Indexes for table `project1`
--
ALTER TABLE `project1`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `projectempdetail`
--
ALTER TABLE `projectempdetail`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task_update`
--
ALTER TABLE `task_update`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `user_account`
--
ALTER TABLE `user_account`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addtask`
--
ALTER TABLE `addtask`
  MODIFY `t_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `comtable`
--
ALTER TABLE `comtable`
  MODIFY `comId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dep_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `division`
--
ALTER TABLE `division`
  MODIFY `div_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `emp`
--
ALTER TABLE `emp`
  MODIFY `emp_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `pro_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `project1`
--
ALTER TABLE `project1`
  MODIFY `pro_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `projectempdetail`
--
ALTER TABLE `projectempdetail`
  MODIFY `d_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `task_update`
--
ALTER TABLE `task_update`
  MODIFY `u_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `t_id` bigint(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `user_account`
--
ALTER TABLE `user_account`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `project`
--
ALTER TABLE `project`
  ADD CONSTRAINT `project_ibfk_1` FOREIGN KEY (`createEmp_id`) REFERENCES `emp` (`emp_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

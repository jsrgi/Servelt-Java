package com.itManage.model;

public class Project {
public int emp_id;
public String  p_name;
public String p_des;
public int p_id;

public int getP_id() {
	return p_id;
}
public void setP_id(int p_id) {
	this.p_id = p_id;
}
public int getEmp_id() {
	return emp_id;
}
public void setEmp_id(int emp_id) {
	this.emp_id = emp_id;
}
public String getP_name() {
	return p_name;
}
public void setP_name(String p_name) {
	this.p_name = p_name;
}
public String getP_des() {
	return p_des;
}
public void setP_des(String p_des) {
	this.p_des = p_des;
}
	
	
	
}

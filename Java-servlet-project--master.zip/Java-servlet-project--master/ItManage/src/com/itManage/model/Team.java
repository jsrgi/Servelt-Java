package com.itManage.model;

public class Team {
	
private String team_name;
private String dep_name;
public String getTeam_name() {
	return team_name;
}
public void setTeam_name(String team_name) {
	this.team_name = team_name;
}
public String getDep_name() {
	return dep_name;
}
public void setDep_name(String dep_name) {
	this.dep_name = dep_name;
}
	
	
}

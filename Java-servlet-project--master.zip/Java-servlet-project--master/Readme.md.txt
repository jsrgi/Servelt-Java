
Import Project:

     1.Download project

     2.extract the file

     3.import to the eclipse IDE

Import Database;

      1.Open the Database folder.

      2.Find the itmanagement.sql

      3.Import to the MYSQL Xamp port.


     Right click on the project and select run on the server.